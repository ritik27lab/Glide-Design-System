import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
    StyleSheet,
    Text,

    TouchableOpacity,
    View,
} from "react-native";
import { useSelector, useDispatch } from "react-redux";
import { storeActions } from "../redux/store";


export const LoginPage = ({ }) => {


    const dispatch = useDispatch()

    const handleData = () => {
        const myDataObj = {
            _id: '_id',
            firstName: 'firstName"',
            name: "name",
            lastName: "lastName",
            profileUrl: "profileUrl",
            imageUrl: "imageUrl",
            phoneNumber: "phoneNumber",
            email: "email",
            DOB: "DOB",
            userType: "userType",
            address: "address",

        };
        dispatch(storeActions.setUserSArr(myDataObj));

    }

    // const userList = useSelector((state) => state.user);

    const { userData } = useSelector((state: any) => ({
        userData: state.store.usersArr,
    }));

    console.log("userData", userData);


    return (
        <View
            style={{
                flex: 1,
                backgroundColor: "#3a2a46",
                justifyContent: "center",
                // alignItems: "center",
            }}
        >

            <Text
                onPress={() => handleData()}
                style={{ fontFamily: 'Quantico-BoldItalic', color: '#fff', fontSize: 24, marginLeft: '5%' }}>
                LET’S ONBOARD
            </Text>
            <Text style={{ fontSize: 16, fontFamily: 'Roboto-Regular', color: '#fff', width: '65%', marginLeft: '5%', marginVertical: 20 }}>
                Please Enter your Mobile Number to get the OTP
            </Text>

            {/* {usersArr.map((user: any) => (
                <Text>{user.firstName}</Text>
            ))} */}


            {/* <TouchableOpacity style={[styles.button]}>
                <Text style={styles.btn_text}>SUBMIT</Text>
            </TouchableOpacity> */}

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
        alignItems: "center",
        flexDirection: "column",
        padding: 50,
    },
    title_text: {
        fontSize: 40,
        fontWeight: "900",
        marginBottom: 55,
    },
    counter_text: {
        fontSize: 35,
        fontWeight: "900",
        color: "red",
        height: 46,
        width: "50%",
        borderRadius: 10,
        margin: 15,

        backgroundColor: "#000000",
        borderWidth: 2,
    },
    btn: {
        backgroundColor: "#086972",
        padding: 10,
        margin: 10,
        borderRadius: 10,
    },
    btn_text: {
        fontSize: 15,
        color: "#fff",
        alignSelf: 'center',
        fontFamily: 'Quantico-BoldItalic',

    },
    button: {
        marginVertical: 10,
        height: 56,
        width: "90%",

        borderRadius: 5,
        justifyContent: "center",
        alignSelf: "center",
        backgroundColor: "#8355B6",
    },
    label: {
        fontSize: 20,
        marginBottom: 10,
    },
    countryPickerContainer: {
        marginBottom: 10,
    },

    countryPickerButton: {
        backgroundColor: "#ddd",
        padding: 10,
        marginRight: 10,
        borderRadius: 5,
    },
    countryPickerButtonText: {
        fontSize: 16,
    },
    phoneNumberInput: {
        flex: 1,
        fontSize: 16,
    },
    codeTxt: {
        color: "#ffffff",
        fontSize: 16,
        fontWeight: "700",
        textAlign: "center",
        justifyContent: "center",
        fontFamily: "Roboto-Medium",
    },

    TandCTxt: {
        fontFamily: "NotoSans-Regular",
        fontSize: 16.5,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        textAlign: "center",
        fontWeight: "500",
        color: "#fff",
        width: '70%',
        top: 50
    },
});
